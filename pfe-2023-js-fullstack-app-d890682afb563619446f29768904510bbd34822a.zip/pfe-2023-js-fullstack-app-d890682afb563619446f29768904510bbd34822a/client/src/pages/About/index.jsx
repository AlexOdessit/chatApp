import React from 'react';
import Header from '../../components/Header';

const AboutPage = () => {
  return (
    <>
      <Header />
      <h1>About</h1>
    </>
  );
};

export default AboutPage;
