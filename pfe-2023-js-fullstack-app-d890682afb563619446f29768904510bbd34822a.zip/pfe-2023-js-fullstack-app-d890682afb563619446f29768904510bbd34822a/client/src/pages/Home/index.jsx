import { useState } from 'react';
import ClassComponent from '../../components/ClassComponent';
import FuncComponent from '../../components/FuncComponent';
import Header from '../../components/Header';

function HomePage() {
  return (
    <>
     <Header />
    </>
  );
}

export default HomePage;
