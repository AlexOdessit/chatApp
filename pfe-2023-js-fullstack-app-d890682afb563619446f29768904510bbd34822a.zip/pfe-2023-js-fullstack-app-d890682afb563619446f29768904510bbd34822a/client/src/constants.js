const CONSTANTS = {
  PLACEHOLDER_USER_PIC: '/assets/images/user-pic-placeholder.png'
}

export default CONSTANTS;